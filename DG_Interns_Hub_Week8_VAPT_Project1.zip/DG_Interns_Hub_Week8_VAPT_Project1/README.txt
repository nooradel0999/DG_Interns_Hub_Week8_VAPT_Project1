DG INTERNS HUB — Week 8: Advanced VAPT Project
Attack Chain & Full Exploitation — OWASP Juice Shop
==================================================
Author: Cyber Security Intern @ DG Interns Hub
Date: October 2026

CONTENTS
--------
01_Report/                Advanced VAPT Report (Word, ~15 pages, EN)
02_Presentation/          Attack Chain Slides (PowerPoint, 7 slides, EN)
03_Captures_Evidence/     20 unified simulated lab captures (PNG)

ATTACK CHAIN SUMMARY
--------------------
Step 1: SQL Injection login bypass      (A03 - Critical)
Step 2: Admin panel access via JWT      (A01 - High)
Step 3: IDOR mass user enumeration      (A01 BOLA - High)
Step 4: bcrypt hash dump + offline crack(A02 - High)
Step 5: /ftp forced browsing + .bak leak(A05 - Medium)
Step 6: Business logic basket abuse     (A04 - Medium)
=> Chained impact: CRITICAL (admin takeover + data breach)

NOTE: All testing performed on the official OWASP Juice Shop
deliberately-vulnerable lab application in an isolated local
environment, for authorized educational purposes only.
